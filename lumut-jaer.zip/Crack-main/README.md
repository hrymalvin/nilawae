### Menu & Fitur Crack
![IMG_20220123_015205](https://user-images.githubusercontent.com/92802033/150651709-758ecee7-0d28-42f4-86cd-b6cb12762e30.jpg)

### Installation
- [ ] pkg update [&&]() pkg upgrade

- [ ] pkg install python2 git

- [ ] pip2 install requests mechanize

- [ ] pip2 install futures bs4

- [ ] git clone https://github.com/AngCyber/Crack

- [ ] cd Crack

- [ ] ls  [(Huruf "L" Kecil)]()

- [ ] git pull 

- [ ] python2 Multi_BF.py

### Results/Hasil
![Screenshot_2022-01-23-01-30-43-06](https://user-images.githubusercontent.com/92802033/150651735-1715a932-060f-4d47-9407-65a8bc2a5ca2.jpg)


### Donasi
- Dana  : [083806858479]()
- Pulsa : [081392979518]()

### Contact Me
- WhatsApp : [089524163441]()
- Youtube : [Aang-XD]()
- Facebook : [Aang.XD404]()
![python-logo-1](https://user-images.githubusercontent.com/92802033/153346252-b3d53c2e-d347-4f37-9e4a-e052a5e4641f.gif)


